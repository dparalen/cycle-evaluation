#!/usr/bin/env python
from Brent import CycleDetect
from lotka_voltera import LotkaVoltera2D
from Filter import ChFilter
from numpy import *
from multiprocessing import Pool
from matplotlib import pyplot

def simMap(X0):
	return LotkaVoltera2D(X0, timeSpace)

def fltMap(sim):
	return ChFilter(sim.result.T, filter)

def cycMap(flt):
	return CycleDetect(flt.result, epsilon=0.3)

if __name__ == "__main__":
	# create a regular grid of init value combinations
	iX, iY = meshgrid(range(100), range(100))
	Z = array([iX, iY])
	# make it a "list of pairs"
	Z.shape = 2, 10000
	# create a time "axis"
	timeSpace = linspace(0, 10, 2000)
	# create a filter representation
	filter = array([[5.0, 2.5], [2.5, 5.0]])
	p = Pool(processes=16)
	simData = p.map(simMap, Z.T)
	fltData = p.map(fltMap, simData)
	cycData = p.map(cycMap, fltData)
	result = array([array([x.start, x.length]) for x in cycData])
	# create a histogram of the data
	H, xedges, yedges = histogram2d(result.T[0], result.T[1])
	extent = [yedges[0], yedges[-1], xedges[-1], xedges[0]]
	pyplot.imshow(H, extent=extent, interpolation='nearest')
	pyplot.colorbar()
	pyplot.show()




